package com.hsbc.vpms.health;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;

import java.awt.*;
import java.io.IOException;
import java.net.URI;

@SpringBootApplication
public class VpmsHealthApplication {

    private final Environment environment;

    public VpmsHealthApplication(Environment environment) {
        this.environment = environment;
    }

    public static void main(String[] args) {
        SpringApplication.run(VpmsHealthApplication.class, args);
    }

    @EventListener(ApplicationReadyEvent.class)
    public void openBrowser() {
        try {
            // 获取配置的端口，默认为8080
            String port = environment.getProperty("server.port", "8888");
            String url = "http://localhost:" + port;

            // 检查Desktop是否支持
            if (Desktop.isDesktopSupported()) {
                Desktop desktop = Desktop.getDesktop();
                // 检查是否支持浏览功能
                if (desktop.isSupported(Desktop.Action.BROWSE)) {
                    desktop.browse(new URI(url));
                    System.out.println("浏览器已打开: " + url);
                } else {
                    System.out.println("当前系统不支持自动打开浏览器");
                }
            } else {
                // 尝试使用系统命令打开浏览器
                openBrowserWithCommand(url);
            }
        } catch (Exception e) {
            System.err.println("打开浏览器失败: " + e.getMessage());
        }
    }

    private void openBrowserWithCommand(String url) {
        try {
            String os = System.getProperty("os.name").toLowerCase();
            Runtime runtime = Runtime.getRuntime();

            if (os.contains("win")) {
                // Windows系统
                runtime.exec("rundll32 url.dll,FileProtocolHandler " + url);
            } else if (os.contains("mac")) {
                // macOS系统
                runtime.exec("open " + url);
            } else if (os.contains("nix") || os.contains("nux")) {
                // Linux系统
                runtime.exec("xdg-open " + url);
            } else {
                System.out.println("无法识别的操作系统，无法自动打开浏览器");
            }
        } catch (IOException e) {
            System.err.println("使用系统命令打开浏览器失败: " + e.getMessage());
        }
    }
}
