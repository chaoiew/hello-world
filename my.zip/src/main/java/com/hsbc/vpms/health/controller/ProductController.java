package com.hsbc.vpms.health.controller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

@RestController
public class ProductController {

    @GetMapping(value = "/api/products", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getProducts() throws IOException {
        ClassPathResource resource = new ClassPathResource("products.json");
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8))) {
            return reader.lines().collect(Collectors.joining("\n"));
        }
    }

    @GetMapping(value = "/api/product/{locale}/{product}/request/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getProductRequestJson(
            @PathVariable String locale,
            @PathVariable String product) {

        try {
            // 构造文件路径: locales/{locale}/{product}_Request.json
            String filePath = "locales/" + locale + "/" + product + "_Request.json";
            ClassPathResource resource = new ClassPathResource(filePath);

            if (!resource.exists()) {
                return ResponseEntity.notFound().build();
            }

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8))) {
                String content = reader.lines().collect(Collectors.joining("\n"));
                return ResponseEntity.ok(content);
            }
        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
