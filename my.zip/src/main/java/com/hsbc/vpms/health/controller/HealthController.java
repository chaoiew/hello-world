package com.hsbc.vpms.health.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

@RestController
public class HealthController {

    private final RestTemplate restTemplate = new RestTemplate();

    // 从配置文件读取IPE地址
    @Value("${ipe.address}")
    private String ipeAddress;

    @GetMapping("/api/health/{locale}/{product}/{endpoint}")
    public String checkEndpointHealth(
            @PathVariable String locale,
            @PathVariable String product,
            @PathVariable String endpoint) {

        try {
            // 根据endpoint确定请求的URL，使用配置的ipe.address
            String apiUrl;
            switch (endpoint) {
                case "illu":
                    apiUrl = ipeAddress + "/ipe/illu";
                    break;
                case "pre":
                    apiUrl = ipeAddress + "/pre";
                    break;
                case "s":
                    apiUrl = ipeAddress + "/s";
                    break;
                default:
                    return "ERROR";
            }

            // 读取请求体文件
            String requestBody = readFile("locales/" + locale + "/" + product + "_" + endpoint + "_Request.json");

            // 调用对应的API
            String actualResponse = callApi(apiUrl, requestBody);

            // 读取期望的响应文件
            String expectedResponse = readFile("locales/" + locale + "/" + product + "_" + endpoint + "_Response.json");

            // 比较响应结果
            return actualResponse.equals(expectedResponse) ? "OK" : "ERROR";

        } catch (Exception e) {
            e.printStackTrace();
            return "ERROR";
        }
    }

    private String readFile(String fileName) throws IOException {
        ClassPathResource resource = new ClassPathResource(fileName);
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8))) {
            return reader.lines().collect(Collectors.joining("\n"));
        }
    }

    private String callApi(String endpoint, String requestBody) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(endpoint, entity, String.class);
        return response.getBody();
    }
}
