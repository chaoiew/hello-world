package com.hsbc.ipe.vpms.tool;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;

public class OpenModelsDirHandler extends AbstractHandler {
    

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        
        // 打开这个目录
        CommonUtil.openDirectory("/opt/vpms-server/models");
        
        return null;
    }
}    