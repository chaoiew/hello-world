package com.hsbc.ipe.vpms.tool;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.SubMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.IConsoleManager;
import org.eclipse.ui.console.MessageConsole;
import org.eclipse.ui.console.MessageConsoleStream;

public class CommonUtil {
	public static final Path VPM_FILE = Paths.get("/opt/vpms-server/models/life-models");
	public static final Path BAK_FILE = Paths.get("/opt/vpms-server/models/life-models_BAK");
    
   
    public static boolean isVpmRenamed() {
    	return Files.exists(BAK_FILE);
    };
    
    /**
     * 压缩目录为ZIP文件
     * @param sourceDirectory 源目录路径
     * @param zipFilePath 目标ZIP文件路径
     * @param monitor 进度监视器
     * @throws IOException 如果压缩过程中发生IO错误
     */
    public static void zipDirectory(String sourceDirectory, String zipFilePath, IProgressMonitor monitor) throws IOException {
        File sourceDir = new File(sourceDirectory);
        File zipFile = new File(zipFilePath);
        
        // 检查源目录是否存在
        if (!sourceDir.exists() || !sourceDir.isDirectory()) {
            throw new IOException("源目录不存在或不是目录: " + sourceDirectory);
        }
        
        // 创建父目录（如果不存在）
        if (!zipFile.getParentFile().exists()) {
            zipFile.getParentFile().mkdirs();
        }
        
        // 计算总工作量（文件数量）
        int totalWork = countFiles(sourceDir);
        SubMonitor subMonitor = SubMonitor.convert(monitor, "压缩目录: " + sourceDirectory, totalWork);
        
        try (FileOutputStream fos = new FileOutputStream(zipFile);
             ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(fos))) { // 修正此处的流包装顺序
            
            // 开始压缩
            zipDirectoryHelper(sourceDir, sourceDir.getAbsolutePath(), zos, subMonitor);
        }
    }
    
    /**
     * 递归压缩目录
     */
    private static void zipDirectoryHelper(File directory, String basePath, ZipOutputStream zos, SubMonitor monitor) throws IOException {
        if (monitor.isCanceled()) {
            throw new IOException("压缩操作已取消");
        }
        
        File[] files = directory.listFiles();
        if (files == null) {
            return;
        }
        
        for (File file : files) {
            if (file.isDirectory()) {
                // 递归压缩子目录
                zipDirectoryHelper(file, basePath, zos, monitor);
            } else {
                // 添加文件到ZIP
                addFileToZip(file, basePath, zos);
                monitor.worked(1);
                monitor.setTaskName("压缩文件: " + file.getName());
            }
        }
    }
    
    /**
     * 将单个文件添加到ZIP流
     */
    private static void addFileToZip(File file, String basePath, ZipOutputStream zos) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            // 计算ZIP条目名称（相对于基础路径）
            String entryName = file.getAbsolutePath().substring(basePath.length() + 1);
            entryName = entryName.replace("\\", "/"); // 确保使用正斜杠
            
            // 创建ZIP条目并添加到流
            ZipEntry zipEntry = new ZipEntry(entryName);
            zos.putNextEntry(zipEntry);
            
            // 写入文件内容
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                zos.write(buffer, 0, bytesRead);
            }
            
            // 关闭条目
            zos.closeEntry();
        }
    }
    
    /**
     * 计算目录中的文件总数（包括子目录中的文件）
     */
    private static int countFiles(File directory) {
        int count = 0;
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    count += countFiles(file);
                } else {
                    count++;
                }
            }
        }
        return count;
    }
    
    
    /**
     * 在Windows资源管理器中打开指定目录
     * @param directoryPath 目录路径（Windows格式，例如："c:\\opt\\vpms-server\\models"）
     * @return 操作是否成功
     */
    public static boolean openDirectory(String directoryPath) {
        // 检查路径是否为空
        if (directoryPath == null || directoryPath.trim().isEmpty()) {
            System.err.println("错误: 目录路径为空");
            return false;
        }

        // 规范化路径（将斜杠转换为反斜杠）
        directoryPath = directoryPath.replace("/", "\\");
        
        // 确保路径不以反斜杠结尾（避免explorer命令错误）
        if (directoryPath.endsWith("\\") && directoryPath.length() > 1) {
            directoryPath = directoryPath.substring(0, directoryPath.length() - 1);
        }

        File directory = new File(directoryPath);

        // 检查目录是否存在
        if (!directory.exists()) {
            System.err.println("错误: 目录不存在 - " + directoryPath);
            return false;
        }

        // 检查是否为目录
        if (!directory.isDirectory()) {
            System.err.println("错误: 指定路径不是目录 - " + directoryPath);
            return false;
        }

        try {
            // 使用explorer命令打开目录
            ProcessBuilder pb = new ProcessBuilder("explorer", directoryPath);
            Process process = pb.start();
            
            // 等待进程启动（非阻塞）
            boolean processStarted = process.waitFor(5, java.util.concurrent.TimeUnit.SECONDS);
            
            if (!processStarted) {
                System.out.println("资源管理器已成功启动，但可能需要更长时间才能显示。");
            } else if (process.exitValue() != 0) {
                System.err.println("错误: 打开目录失败，退出代码: " + process.exitValue());
                return false;
            }
            
            System.out.println("已成功打开目录: " + directoryPath);
            return true;
        } catch (IOException e) {
            System.err.println("错误: 打开目录时发生IO异常 - " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (InterruptedException e) {
            System.err.println("错误: 等待资源管理器启动时被中断 - " + e.getMessage());
            Thread.currentThread().interrupt();
            return false;
        } catch (Exception e) {
            System.err.println("错误: 打开目录时发生异常 - " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public static void executeScript(String[] command, MessageConsoleStream out, Shell shell) {
        new Thread(() -> {
            Process process = null;
            int exitCode = -1;
            try {
                out.println("开始执行脚本: " + String.join(" ", command));
                
                // 创建进程
                ProcessBuilder builder = new ProcessBuilder(command);
                builder.redirectErrorStream(true);
                process = builder.start();
                
                // 读取输出
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    final String outputLine = line;
                    Display.getDefault().asyncExec(() -> out.println(outputLine));
                }
                
                // 等待进程结束
                exitCode = process.waitFor();
                final int finalExitCode = exitCode;
                
                Display.getDefault().asyncExec(() -> {
                    out.println("脚本执行完毕，退出代码: " + finalExitCode);
                    String message = "脚本执行完毕，退出代码: " + finalExitCode;
                    MessageDialog.openInformation(shell, "执行结果", message);
                });
                
            } catch (IOException | InterruptedException e) {
                final String errorMsg = "执行脚本时出错: " + e.getMessage();
                Display.getDefault().asyncExec(() -> {
                    out.println(errorMsg);
                    MessageDialog.openError(shell, "执行失败", errorMsg);
                });
            } finally {
                if (process != null) {
                    process.destroy();
                }
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static MessageConsole findConsole(String name) {
        ConsolePlugin plugin = ConsolePlugin.getDefault();
        IConsoleManager conMan = plugin.getConsoleManager();
        IConsole[] existing = conMan.getConsoles();
        
        for (int i = 0; i < existing.length; i++) {
            if (name.equals(existing[i].getName())) {
                return (MessageConsole) existing[i];
            }
        }
        
        // 创建新控制台
        MessageConsole myConsole = new MessageConsole(name, null);
        conMan.addConsoles(new IConsole[] { myConsole });
        return myConsole;
    }
}
