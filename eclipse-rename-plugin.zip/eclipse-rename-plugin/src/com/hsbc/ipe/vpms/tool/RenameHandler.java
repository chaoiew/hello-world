package com.hsbc.ipe.vpms.tool;

import static com.hsbc.ipe.vpms.tool.CommonUtil.BAK_FILE;
import static com.hsbc.ipe.vpms.tool.CommonUtil.VPM_FILE;
import static com.hsbc.ipe.vpms.tool.CommonUtil.isVpmRenamed;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

public class RenameHandler extends AbstractHandler {
    

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
        
        try {
            String currentFileName = isVpmRenamed() ? BAK_FILE.getFileName().toString() : VPM_FILE.getFileName().toString();
            
            // 显示确认对话框
            boolean confirm = MessageDialog.openConfirm(
                shell, 
                "确认操作", 
                "当前文件名为: " + currentFileName + "\n\n" +
                "是否执行" + (isVpmRenamed() ? "恢复" : "备份") + "操作?"
            );
            
            if (!confirm) {
                return null; // 用户取消操作
            }
            
            if (isVpmRenamed()) {
                // 恢复操作：将.BAK重命名为.VPM
                Files.move(BAK_FILE, VPM_FILE, StandardCopyOption.REPLACE_EXISTING);
                MessageDialog.openInformation(shell, "操作成功", "已恢复文件：" + VPM_FILE);
            } else {
                // 备份操作：将.VPM重命名为.BAK
                Files.move(VPM_FILE, BAK_FILE, StandardCopyOption.REPLACE_EXISTING);
                MessageDialog.openInformation(shell, "操作成功", "已备份文件为：" + BAK_FILE);
            }
           
        } catch (IOException e) {
            MessageDialog.openError(shell, "操作失败", "文件操作出错：" + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
}    