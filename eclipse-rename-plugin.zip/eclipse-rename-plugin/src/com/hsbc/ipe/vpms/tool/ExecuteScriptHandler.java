package com.hsbc.ipe.vpms.tool;

import static com.hsbc.ipe.vpms.tool.CommonUtil.BAK_FILE;
import static com.hsbc.ipe.vpms.tool.CommonUtil.VPM_FILE;
import static com.hsbc.ipe.vpms.tool.CommonUtil.executeScript;
import static com.hsbc.ipe.vpms.tool.CommonUtil.findConsole;
import static com.hsbc.ipe.vpms.tool.CommonUtil.isVpmRenamed;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.console.MessageConsole;
import org.eclipse.ui.console.MessageConsoleStream;
import org.eclipse.ui.handlers.HandlerUtil;

public class ExecuteScriptHandler extends AbstractHandler {

    private static final String SCRIPT_PATH = "/opt/copy_to_life_models.bat";
    private static final String TARGET_DIR = "/opt/vpms-server/models/life-models";

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        Shell shell = HandlerUtil.getActiveShell(event);

        // 询问用户是否确认执行
        boolean confirm = MessageDialog.openConfirm(shell, "确认执行", 
                "是否确认执行脚本: " + SCRIPT_PATH + "?\n\n" +
                "此操作会先清空目录: " + TARGET_DIR);
        
        if (!confirm) {
            return null;
        }

       
        if(isVpmRenamed()) {
        	try {
				Files.move(BAK_FILE, VPM_FILE, StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				e.printStackTrace();
				MessageDialog.openError(shell, "执行失败", "重命名为life-models失败: " + BAK_FILE);
			}
        }
        
        // 清空目标目录
        boolean cleared = clearDirectory(new File(TARGET_DIR));
        if (!cleared) {
            MessageDialog.openError(shell, "执行失败", "清空目录时出错: " + TARGET_DIR);
            return null;
        }
        
       

        // 创建或获取控制台
        MessageConsole console = findConsole("脚本执行控制台");
        MessageConsoleStream out = console.newMessageStream();
        out.println("/opt/vpms-server/models/life-models 已经清空，开始执行Copy脚本");
        // 执行脚本
        executeScript(new String[] { "cmd.exe", "/c", SCRIPT_PATH}, out, shell);
        
        // 打开这个目录
        CommonUtil.openDirectory("/opt/vpms-server/models");        
        return null;
    }

    private boolean clearDirectory(File directory) {
        if (!directory.exists() || !directory.isDirectory()) {
            return false;
        }
        
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    if (!clearDirectory(file)) {
                        return false;
                    }
                }
                if (!file.delete()) {
                    return false;
                }
            }
        }
        return true;
    }

    
}    